<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://wordpress.com
 * @since      1.0.0
 *
 * @package    Hd_Custom_Shipping
 * @subpackage Hd_Custom_Shipping/public/partials
 */
?>
